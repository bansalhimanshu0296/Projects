# -*- coding: utf-8 -*-
"""
Created on Sat Jul 27 05:33:18 2019

@author: Hack5GURTeam24
"""
import travelvision_classifier as tvc
from pymongo import MongoClient
category = tvc.Y_final
client = MongoClient("localhost",27017,connect=False)
db=client.travelvision
cities=db.cities
result=cities.find({"Category":category[0]},{"_id":0,"Name":1})
places=[]
for x in result:
    places.append(x["Name"])
print(places)