# -*- coding: utf-8 -*-
"""
Created on Sat Jul 27 03:57:46 2019

@author: Hack5GURTeam24
"""

from pymongo import MongoClient
client = MongoClient("localhost",27017,connect=False)
db=client.travelvision
cities=db.cities
result=cities.find({"$or":[{"Season":"Throughout Year"},{"Season":"Summer"}]},{"_id":0,"Name":1})
places_sum=[]
for x in result:
    places_sum.append(x["Name"])
result=cities.find({"$or":[{"Season":"Throughout Year"},{"Season":"Winter"}]},{"_id":0,"Name":1})
places_win=[]
for x in result:
    places_win.append(x["Name"])
result=cities.find({"$or":[{"Season":"Throughout Year"},{"Season":"Spring/Autmn"},{"Season":"Spring"},{"Season":"Autmn"}]},{"_id":0,"Name":1})
places_sa=[]
for x in result:
    places_sa.append(x["Name"])
places={"Summer":places_sum,"Winter":places_win,"Spring/Autmn":places_sa}
print(places)