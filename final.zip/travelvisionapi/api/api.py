import flask
from flask import jsonify
import travelvision_classifier as tvc
from pymongo import MongoClient

app = flask.Flask(__name__)
app.config["DEBUG"] = True


@app.route('/getpreferences', methods=['GET'])
def home():
    #type=request.args.get("type")
    #preferences=request.args.get("preferences")
    category = tvc.Y_final
    client = MongoClient("localhost",27017,connect=False)
    db=client.travelvision
    cities=db.cities
    result=cities.find({"Category":category[0]},{"_id":0,"Name":1})
    places=[]
    for x in result:    
        places.append(x["Name"])
    places={"places":places}
    return jsonify(places)
@app.route('/getseason', methods=['GET'])
def home1():
    client = MongoClient("localhost",27017,connect=False)
    db=client.travelvision
    cities=db.cities
    result=cities.find({"$or":[{"Season":"Throughout Year"},{"Season":"Summer"}]},{"_id":0,"Name":1})
    places_sum=[]
    for x in result:
        places_sum.append(x["Name"])
    result=cities.find({"$or":[{"Season":"Throughout Year"},{"Season":"Winter"}]},{"_id":0,"Name":1})
    places_win=[]
    for x in result:
        places_win.append(x["Name"])
    result=cities.find({"$or":[{"Season":"Throughout Year"},{"Season":"Spring/Autmn"},{"Season":"Spring"},{"Season":"Autmn"}]},{"_id":0,"Name":1})
    places_sa=[]
    for x in result:
        places_sa.append(x["Name"])
    places={"Summer":places_sum,"Winter":places_win,"Spring/Autmn":places_sa}
    return jsonify(places)
@app.route('/getadventure', methods=['GET'])
def home2():
    client = MongoClient("localhost",27017,connect=False)
    db=client.travelvision
    cities=db.cities
    result=cities.find({"Category":{"$regex" :".*Adventure Sports*."}},{"_id":0,"Name":1})
    places=[]
    for x in result:
        places.append(x["Name"])
    places={"places":places}
    return jsonify(places)

app.run()