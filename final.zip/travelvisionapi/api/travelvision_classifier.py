# -*- coding: utf-8 -*-
"""
Created on Fri Jul 26 12:37:12 2019

@author: Hack5GURTeam24
"""
import numpy as np
import pandas as pd
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
df=pd.read_csv("city.csv")
X=df.iloc[:,2:4].values
Y=df.iloc[:,4].values
labelencoder_X = LabelEncoder()
X[:, 0] = labelencoder_X.fit_transform(X[:, 0])
onehotencoder = OneHotEncoder(categorical_features = [0])
X[:, 1] = labelencoder_X.fit_transform(X[:, 1])
X = onehotencoder.fit_transform(X).toarray()
model = GaussianNB()
model.fit(X,Y)
X_test=df.iloc[:,2:4].values
Y_test=df.iloc[:,4].values
XP=["Beaches","Water Sports, Adventure Sports, Beaches"]
np.append(X_test,XP)
X_test[:, 0] = labelencoder_X.fit_transform(X_test[:, 0])
onehotencoder = OneHotEncoder(categorical_features = [0])
X_test[:, 1] = labelencoder_X.fit_transform(X_test[:, 1])
X_test = onehotencoder.fit_transform(X_test).toarray()
Y_final=model.predict([X_test[-1]])
