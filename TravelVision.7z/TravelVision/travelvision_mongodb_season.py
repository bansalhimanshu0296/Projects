# -*- coding: utf-8 -*-
"""
Created on Sat Jul 27 03:57:46 2019

@author: Hack5GURTeam24
"""

from pymongo import MongoClient
client = MongoClient("localhost",27017,connect=False)
db=client.travelvision
cities=db.cities
result=cities.find({"$or":[{"Season":"Throughout Year"},{"Season":"Summer"}]},{"_id":0,"Name":1})
places_sum=[]
for x in result:
    places_sum.append(x["Name"])
print(places_sum)