# -*- coding: utf-8 -*-
"""
Created on Sat Jul 27 03:02:02 2019

@author: Hack5GURTeam24
"""

import pandas as pd
from pymongo import MongoClient
client = MongoClient("localhost",27017,connect=False)
db=client.travelvision
cities=db.cities
df=pd.read_csv("city.csv")
records=df.to_dict(orient='records')
cities.delete_many({})
result=cities.insert_many(records)
