<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'login' => 'user/login',
  'logout' => 'user/logout',
); ?>