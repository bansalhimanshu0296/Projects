<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 
  array (
    'category_id' => '1',
    'name' => 'Arts',
    'url' => 'http://jyc.club/social/index.php?do=/event/category/1/arts/',
    'sub' => 
    array (
    ),
  ),
  1 => 
  array (
    'category_id' => '2',
    'name' => 'Party',
    'url' => 'http://jyc.club/social/index.php?do=/event/category/2/party/',
    'sub' => 
    array (
    ),
  ),
  2 => 
  array (
    'category_id' => '3',
    'name' => 'Comedy',
    'url' => 'http://jyc.club/social/index.php?do=/event/category/3/comedy/',
    'sub' => 
    array (
    ),
  ),
  3 => 
  array (
    'category_id' => '4',
    'name' => 'Sports',
    'url' => 'http://jyc.club/social/index.php?do=/event/category/4/sports/',
    'sub' => 
    array (
    ),
  ),
  4 => 
  array (
    'category_id' => '5',
    'name' => 'Music',
    'url' => 'http://jyc.club/social/index.php?do=/event/category/5/music/',
    'sub' => 
    array (
    ),
  ),
  5 => 
  array (
    'category_id' => '6',
    'name' => 'TV',
    'url' => 'http://jyc.club/social/index.php?do=/event/category/6/tv/',
    'sub' => 
    array (
    ),
  ),
  6 => 
  array (
    'category_id' => '7',
    'name' => 'Movies',
    'url' => 'http://jyc.club/social/index.php?do=/event/category/7/movies/',
    'sub' => 
    array (
    ),
  ),
  7 => 
  array (
    'category_id' => '8',
    'name' => 'Other',
    'url' => 'http://jyc.club/social/index.php?do=/event/category/8/other/',
    'sub' => 
    array (
    ),
  ),
); ?>