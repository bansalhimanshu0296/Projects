<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 'blog',
  1 => 'forum',
  2 => 'photo',
  3 => 'video',
); ?>