<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'USD' => 
  array (
    'symbol' => '&#36;',
    'name' => 'core.u_s_dollars',
    'is_default' => '1',
  ),
  'EUR' => 
  array (
    'symbol' => '&#8364;',
    'name' => 'core.euros',
    'is_default' => '0',
  ),
  'GBP' => 
  array (
    'symbol' => '&#163;',
    'name' => 'core.pounds_sterling',
    'is_default' => '0',
  ),
); ?>