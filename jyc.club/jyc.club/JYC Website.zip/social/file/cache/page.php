<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'about' => '1',
  'policy' => '2',
  'terms' => '3',
); ?>