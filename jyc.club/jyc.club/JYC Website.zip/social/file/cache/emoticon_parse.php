<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  ':)' => 
  array (
    'title' => 'Smile',
    'text' => ':)',
    'image' => 'smile.png',
    'package_path' => 'default',
  ),
  '>;->' => 
  array (
    'title' => 'Evilgrin',
    'text' => '>;->',
    'image' => 'evilgrin.png',
    'package_path' => 'default',
  ),
  ':-)' => 
  array (
    'title' => 'Happy',
    'text' => ':-)',
    'image' => 'happy.png',
    'package_path' => 'default',
  ),
  ';)' => 
  array (
    'title' => 'Wink',
    'text' => ';)',
    'image' => 'wink.png',
    'package_path' => 'default',
  ),
  ':P' => 
  array (
    'title' => 'Tongue',
    'text' => ':P',
    'image' => 'tongue.png',
    'package_path' => 'default',
  ),
  ':(' => 
  array (
    'title' => 'Unhappy',
    'text' => ':(',
    'image' => 'unhappy.png',
    'package_path' => 'default',
  ),
  '=:o' => 
  array (
    'title' => 'Surprised',
    'text' => '=:o',
    'image' => 'surprised.png',
    'package_path' => 'default',
  ),
  ':>' => 
  array (
    'title' => 'Grin',
    'text' => ':>',
    'image' => 'grin.png',
    'package_path' => 'default',
  ),
); ?>