<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 'blog',
  1 => 'comment',
  2 => 'event',
  3 => 'forum',
  4 => 'invite',
  5 => 'mail',
  6 => 'marketplace',
  7 => 'music',
  8 => 'photo',
  9 => 'poll',
  10 => 'quiz',
  11 => 'user',
  12 => 'video',
); ?>