<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 'blog',
  1 => 'event',
  2 => 'marketplace',
  3 => 'music',
  4 => 'photo',
  5 => 'poll',
  6 => 'quiz',
  7 => 'video',
); ?>