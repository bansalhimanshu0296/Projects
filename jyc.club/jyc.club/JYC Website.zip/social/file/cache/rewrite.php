<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'user/login' => 'login',
  'user/logout' => 'logout',
); ?>