<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 'comment',
  1 => 'forum',
  2 => 'friend',
  3 => 'like',
  4 => 'mail',
  5 => 'newsletter',
); ?>