<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 
  array (
    'genre_id' => '4',
    'name' => 'Alternative',
    'name_url' => NULL,
  ),
  1 => 
  array (
    'genre_id' => '19',
    'name' => 'Blues',
    'name_url' => NULL,
  ),
  2 => 
  array (
    'genre_id' => '18',
    'name' => 'Classic Rock',
    'name_url' => NULL,
  ),
  3 => 
  array (
    'genre_id' => '5',
    'name' => 'Country',
    'name_url' => NULL,
  ),
  4 => 
  array (
    'genre_id' => '13',
    'name' => 'Electronica',
    'name_url' => NULL,
  ),
  5 => 
  array (
    'genre_id' => '20',
    'name' => 'Folk',
    'name_url' => NULL,
  ),
  6 => 
  array (
    'genre_id' => '11',
    'name' => 'Hardcore',
    'name_url' => NULL,
  ),
  7 => 
  array (
    'genre_id' => '1',
    'name' => 'Hip Hop',
    'name_url' => NULL,
  ),
  8 => 
  array (
    'genre_id' => '12',
    'name' => 'House',
    'name_url' => NULL,
  ),
  9 => 
  array (
    'genre_id' => '6',
    'name' => 'Indie',
    'name_url' => NULL,
  ),
  10 => 
  array (
    'genre_id' => '17',
    'name' => 'Jazz',
    'name_url' => NULL,
  ),
  11 => 
  array (
    'genre_id' => '16',
    'name' => 'Latin',
    'name_url' => NULL,
  ),
  12 => 
  array (
    'genre_id' => '9',
    'name' => 'Metal',
    'name_url' => NULL,
  ),
  13 => 
  array (
    'genre_id' => '3',
    'name' => 'Pop',
    'name_url' => NULL,
  ),
  14 => 
  array (
    'genre_id' => '21',
    'name' => 'Progressive',
    'name_url' => NULL,
  ),
  15 => 
  array (
    'genre_id' => '10',
    'name' => 'Punk',
    'name_url' => NULL,
  ),
  16 => 
  array (
    'genre_id' => '8',
    'name' => 'R&B',
    'name_url' => NULL,
  ),
  17 => 
  array (
    'genre_id' => '7',
    'name' => 'Rap',
    'name_url' => NULL,
  ),
  18 => 
  array (
    'genre_id' => '15',
    'name' => 'Reggae',
    'name_url' => NULL,
  ),
  19 => 
  array (
    'genre_id' => '2',
    'name' => 'Rock',
    'name_url' => NULL,
  ),
  20 => 
  array (
    'genre_id' => '14',
    'name' => 'Techno',
    'name_url' => NULL,
  ),
); ?>