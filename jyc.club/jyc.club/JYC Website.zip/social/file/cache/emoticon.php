<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 
  array (
    'title' => 'Smile',
    'text' => ':)',
    'image' => 'smile.png',
    'package_path' => 'default',
  ),
  1 => 
  array (
    'title' => 'Evilgrin',
    'text' => '>;->',
    'image' => 'evilgrin.png',
    'package_path' => 'default',
  ),
  2 => 
  array (
    'title' => 'Happy',
    'text' => ':-)',
    'image' => 'happy.png',
    'package_path' => 'default',
  ),
  3 => 
  array (
    'title' => 'Wink',
    'text' => ';)',
    'image' => 'wink.png',
    'package_path' => 'default',
  ),
  4 => 
  array (
    'title' => 'Tongue',
    'text' => ':P',
    'image' => 'tongue.png',
    'package_path' => 'default',
  ),
  5 => 
  array (
    'title' => 'Unhappy',
    'text' => ':(',
    'image' => 'unhappy.png',
    'package_path' => 'default',
  ),
  6 => 
  array (
    'title' => 'Surprised',
    'text' => '=:o',
    'image' => 'surprised.png',
    'package_path' => 'default',
  ),
  7 => 
  array (
    'title' => 'Grin',
    'text' => ':>',
    'image' => 'grin.png',
    'package_path' => 'default',
  ),
); ?>