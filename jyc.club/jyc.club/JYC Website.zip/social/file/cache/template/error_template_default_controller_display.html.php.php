<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php /* Cached: March 18, 2015, 9:11 pm */ ?>
<?php 
/**
 * [NULLED BY DARKGOTH 2014]
 * 
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		Raymond Benc
 * @package  		Module_Error
 * @version 		$Id: display.html.php 4410 2012-06-28 08:51:00Z Miguel_Espinoza $
 */
 
 

 if (isset ( $this->_aVars['sErrorMessage'] )): ?>
<?php echo $this->_aVars['sErrorMessage'];  endif; ?>
