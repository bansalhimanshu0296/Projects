<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php /* Cached: March 18, 2015, 9:01 pm */ ?>
<?php 
/**
 * [NULLED BY DARKGOTH 2014]
 * 
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		Raymond Benc
 * @package  		Module_Core
 * @version 		$Id: message.html.php 6411 2013-08-03 10:11:02Z Raymond_Benc $
 */
 
 

?>
<div id="js_custom_core_message">
<?php echo $this->_aVars['sMessage']; ?>
</div>
