<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php /* Cached: March 18, 2015, 8:47 pm */ ?>
<?php 
/**
 * [NULLED BY DARKGOTH 2014]
 * 
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		Raymond Benc
 * @package  		Module_User
 * @version 		$Id: register.html.php 303 2009-03-22 20:08:08Z Raymond_Benc $
 */
 
 


						Phpfox::getLib('template')->getBuiltFile('user.controller.register');						
						?>
