<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php /* Cached: March 18, 2015, 8:44 pm */ ?>
<?php 
/**
 * [NULLED BY DARKGOTH 2014]
 * 
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		Raymond_Benc
 * @package 		Phpfox
 * @version 		$Id: notify.html.php 3335 2011-10-20 17:26:57Z Raymond_Benc $
 */
 
 

?>
<li>
	<span class="holder_notify_count" id="js_total_new_notifications">0</span>
	<a href="#" title="<?php echo Phpfox::getPhrase('notification.notifications'); ?>" class="notification notify_drop_link" rel="notification.getAll"><span class="icon"></span><span class="phrase"><?php echo Phpfox::getPhrase('notification.notifications'); ?></span></a>
</li>	
