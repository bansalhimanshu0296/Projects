<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php /* Cached: March 18, 2015, 8:50 pm */ ?>
[CONTENT]
<div id="block_listing">
	<div class="active_blocks">
		Blocks
	</div>
<?php echo $this->_aVars['all_blocks']; ?>
</div>
