<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php /* Cached: March 18, 2015, 8:47 pm */ ?>
<?php
						Phpfox::getLib('template')->getBuiltFile('user.controller.login');						
						?>
