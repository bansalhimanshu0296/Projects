<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 'blog',
  1 => 'comment',
  2 => 'user',
); ?>