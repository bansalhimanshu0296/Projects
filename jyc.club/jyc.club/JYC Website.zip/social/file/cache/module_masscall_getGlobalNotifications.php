<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 'friend',
  1 => 'mail',
  2 => 'notification',
); ?>