<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'http://jyc.club/social/index.php?do=/rss/id_1/' => 'Latest Blogs',
  'http://jyc.club/social/index.php?do=/rss/id_3/' => 'Latest Events',
  'http://jyc.club/social/index.php?do=/rss/id_4/' => 'Latest Forum Topics',
  'http://jyc.club/social/index.php?do=/rss/id_5/' => 'Latest Videos',
); ?>