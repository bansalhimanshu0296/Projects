<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 
  array (
    'category_id' => '1',
    'ordering' => '0',
    'title' => 'Sales',
  ),
  1 => 
  array (
    'category_id' => '2',
    'ordering' => '1',
    'title' => 'Support',
  ),
  2 => 
  array (
    'category_id' => '3',
    'ordering' => '2',
    'title' => 'Suggestions',
  ),
); ?>