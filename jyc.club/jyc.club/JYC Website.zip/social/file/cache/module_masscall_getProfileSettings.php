<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 'feed',
  1 => 'friend',
  2 => 'mail',
  3 => 'photo',
  4 => 'poke',
  5 => 'profile',
  6 => 'rate',
  7 => 'rss',
  8 => 'track',
  9 => 'user',
); ?>