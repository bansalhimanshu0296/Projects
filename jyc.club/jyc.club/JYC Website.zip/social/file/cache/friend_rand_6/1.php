<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 
  array (
    'dob_setting' => '0',
    'friend_id' => '1',
    'friend_user_id' => '2',
    'is_top_friend' => '0',
    'time_stamp' => '1426713300',
    'user_id' => '2',
    'profile_page_id' => '0',
    'user_server_id' => '0',
    'user_name' => 'profile-2',
    'full_name' => 'puru',
    'gender' => '0',
    'user_image' => NULL,
    'is_invisible' => '0',
    'user_group_id' => '2',
    'language_id' => 'en',
  ),
); ?>