<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 'blog',
  1 => 'comment',
  2 => 'event',
  3 => 'feed',
  4 => 'forum',
  5 => 'marketplace',
  6 => 'music',
  7 => 'pages',
  8 => 'photo',
  9 => 'poll',
  10 => 'user',
  11 => 'video',
); ?>