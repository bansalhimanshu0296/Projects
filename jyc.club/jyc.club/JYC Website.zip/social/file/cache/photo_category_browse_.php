<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 
  array (
    'category_id' => '1',
    'name' => 'Anthro',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/1/anthro/',
    'sub' => 
    array (
    ),
  ),
  1 => 
  array (
    'category_id' => '2',
    'name' => 'Artisan Crafts',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/2/artisan-crafts/',
    'sub' => 
    array (
    ),
  ),
  2 => 
  array (
    'category_id' => '3',
    'name' => 'Cartoons & Comics',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/3/cartoons-comics/',
    'sub' => 
    array (
    ),
  ),
  3 => 
  array (
    'category_id' => '4',
    'name' => 'Comedy',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/4/comedy/',
    'sub' => 
    array (
    ),
  ),
  4 => 
  array (
    'category_id' => '5',
    'name' => 'Community Projects',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/5/community-projects/',
    'sub' => 
    array (
    ),
  ),
  5 => 
  array (
    'category_id' => '6',
    'name' => 'Contests',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/6/contests/',
    'sub' => 
    array (
    ),
  ),
  6 => 
  array (
    'category_id' => '7',
    'name' => 'Customization',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/7/customization/',
    'sub' => 
    array (
    ),
  ),
  7 => 
  array (
    'category_id' => '8',
    'name' => 'Designs & Interfaces',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/8/designs-interfaces/',
    'sub' => 
    array (
    ),
  ),
  8 => 
  array (
    'category_id' => '9',
    'name' => 'Digital Art',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/9/digital-art/',
    'sub' => 
    array (
    ),
  ),
  9 => 
  array (
    'category_id' => '10',
    'name' => 'Fan Art',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/10/fan-art/',
    'sub' => 
    array (
    ),
  ),
  10 => 
  array (
    'category_id' => '11',
    'name' => 'Film & Animation',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/11/film-animation/',
    'sub' => 
    array (
    ),
  ),
  11 => 
  array (
    'category_id' => '12',
    'name' => 'Fractal Art',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/12/fractal-art/',
    'sub' => 
    array (
    ),
  ),
  12 => 
  array (
    'category_id' => '13',
    'name' => 'Game Development Art',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/13/game-development-art/',
    'sub' => 
    array (
    ),
  ),
  13 => 
  array (
    'category_id' => '14',
    'name' => 'Literature',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/14/literature/',
    'sub' => 
    array (
    ),
  ),
  14 => 
  array (
    'category_id' => '15',
    'name' => 'People',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/15/people/',
    'sub' => 
    array (
    ),
  ),
  15 => 
  array (
    'category_id' => '16',
    'name' => 'Pets & Animals',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/16/pets-animals/',
    'sub' => 
    array (
    ),
  ),
  16 => 
  array (
    'category_id' => '17',
    'name' => 'Photography',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/17/photography/',
    'sub' => 
    array (
    ),
  ),
  17 => 
  array (
    'category_id' => '18',
    'name' => 'Resources & Stock Images',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/18/resources-stock-images/',
    'sub' => 
    array (
    ),
  ),
  18 => 
  array (
    'category_id' => '19',
    'name' => 'Science & Technology',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/19/science-technology/',
    'sub' => 
    array (
    ),
  ),
  19 => 
  array (
    'category_id' => '20',
    'name' => 'Sports',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/20/sports/',
    'sub' => 
    array (
    ),
  ),
  20 => 
  array (
    'category_id' => '21',
    'name' => 'Traditional Art',
    'url' => 'http://jyc.club/social/index.php?do=/photo/category/21/traditional-art/',
    'sub' => 
    array (
    ),
  ),
); ?>