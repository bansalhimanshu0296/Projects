<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = 'if ($oReq->get(\'req1\') == \'hashtag\')
{
	$this->_sModule = \'core\';
	$this->_sController = \'index-member\';
} '; ?>