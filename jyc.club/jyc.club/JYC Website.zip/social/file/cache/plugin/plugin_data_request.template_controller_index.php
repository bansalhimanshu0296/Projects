<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = 'Phpfox::getBlock(\'comment.moderate\'); '; ?>