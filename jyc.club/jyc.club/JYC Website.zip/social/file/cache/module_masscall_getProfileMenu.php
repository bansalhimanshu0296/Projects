<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 'blog',
  1 => 'comment',
  2 => 'event',
  3 => 'friend',
  4 => 'marketplace',
  5 => 'music',
  6 => 'pages',
  7 => 'photo',
  8 => 'poll',
  9 => 'quiz',
  10 => 'video',
); ?>