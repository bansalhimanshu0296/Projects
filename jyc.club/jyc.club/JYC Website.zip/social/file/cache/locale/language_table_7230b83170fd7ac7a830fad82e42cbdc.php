<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  0 => 
  array (
    'language_id' => 'en',
    'parent_id' => NULL,
    'title' => 'English (US)',
    'user_select' => '1',
    'language_code' => 'en',
    'charset' => 'UTF-8',
    'direction' => 'ltr',
    'flag_id' => 'png',
    'time_stamp' => '1184048203',
    'created' => 'N/A (Core)',
    'site' => '',
    'is_default' => '1',
    'is_master' => '1',
    'image' => '',
  ),
); ?>