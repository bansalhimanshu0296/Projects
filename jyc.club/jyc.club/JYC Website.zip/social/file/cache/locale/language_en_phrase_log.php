<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'module_log' => 'Log',
  'recent_logins' => 'Recent Logins',
  'admincp_dashboard' => 'AdminCP Dashboard',
  'site_index' => 'Site Index',
  'current_active_users' => 'Current Active Users',
  'members_members_and_guests_guests' => '{members} members and {guests} Guests',
  'view' => 'View',
  'save' => 'Save',
  'cancel' => 'Cancel',
  'everyone' => 'Everyone',
  'friends_only' => 'Friends Only',
  'active_users_total' => 'Active Users ({total})',
); ?>