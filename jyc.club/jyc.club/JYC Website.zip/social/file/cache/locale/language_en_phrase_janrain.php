<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'module_janrain' => 'Janrain',
  'setting_enable_janrain_login' => '<title>Enable Janrain Integration</title><info>Set this to "True" to enable this integration.</info>',
  'setting_janrain_api_key' => '<title>Janrain API Key (Secret)</title><info>Enter your Jainrain API Key (Secret) here.</info>',
  'setting_janrain_application_domain' => '<title>Application Domain</title><info>Enter your "Application Domain" here.</info>',
  'your_account_has_successfully_been_created_please_enter_your_account_details_below' => 'Your account has successfully been created. Please enter your account details below.',
); ?>