<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'module_request' => 'Request',
  'setting_display_request_box_on_empty' => '<title>Display Request Box</title><info>Select True if you would like to display the requests (eg. friend requests) block on the sites index page even when a user has no requests.</info>',
  'requests' => 'Requests',
  'confirm_requests' => 'Confirm Requests',
  'invalid_request_redirect' => 'Invalid request redirect.',
  'there_are_no_new_requests' => 'There are no new requests.',
); ?>