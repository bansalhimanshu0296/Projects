<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'user_setting_show_tips' => 'Show tips?',
  'module_help' => 'Help',
  'add_new_phrase' => 'Add New Phrase',
  'click_for_help' => 'Click for Help',
  'hide_all_tips' => 'Hide All Tips',
  'close' => 'Close',
  'hide_this_tip' => 'Hide This Tip',
  'add_back_tips_info' => '<b>Note:</b> If you close all tips found on this site you can edit your <b>Account Settings</b> to view tips again.',
); ?>