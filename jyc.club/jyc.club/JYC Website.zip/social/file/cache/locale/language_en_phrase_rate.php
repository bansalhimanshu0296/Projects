<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'module_rate' => 'Rate',
  'unable_to_load_rating_callback' => 'Unable to load rating callback.',
  'not_a_valid_post' => 'Not a valid POST.',
  'not_a_valid_item_to_rate' => 'Not a valid item to rate.',
  'sorry_you_are_not_able_to_rate_your_own_item' => 'Sorry, you are not able to rate your own item.',
  'you_have_already_voted_on_this_item' => 'You have already voted on this item.',
  'thanks_for_rating' => 'Thanks for rating!',
  'rate' => 'Rate',
); ?>