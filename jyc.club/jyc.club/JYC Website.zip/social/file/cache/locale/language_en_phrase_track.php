<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'recently_viewed_by' => 'Recently Viewed By',
  'recent_visitors' => 'Recent Visitors',
  'recent_views' => 'Recent Views',
  'setting_cache_recently_viewed_by_timeout' => '<title>Recently Viewed Refresh</title><info>The cache will be refreshed after X minutes. 0 for no cache.</info>',
  'setting_cache_allow_recurrent_visit' => '<title>Refresh Profile Visitor List</title><info>How long before the same user is added to the list again. Minutes, 0 for no cache.</info>',
); ?>