<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '82',
  'type_id' => '0',
  'ordering' => '4',
  'm_connection' => 'music.browse.album',
  'component' => 'featured-album',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'music',
  'source_parsed' => NULL,
); ?>