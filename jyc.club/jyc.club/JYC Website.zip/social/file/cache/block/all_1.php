<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'photo.rate' => 
  array (
    3 => 
    array (
      'photo.stat' => NULL,
    ),
    1 => 
    array (
      'photo.category' => NULL,
    ),
  ),
  'photo.profile' => 
  array (
    1 => 
    array (
      'profile.pic' => NULL,
    ),
  ),
  'core.index' => 
  array (
    0 => 
    array (
      'forum.timezone' => NULL,
    ),
    1 => 
    array (
      'blog.new-blogs' => NULL,
    ),
  ),
  'marketplace.profile' => 
  array (
    1 => 
    array (
      'profile.pic' => NULL,
    ),
  ),
  'music.profile' => 
  array (
    1 => 
    array (
      'profile.pic' => NULL,
    ),
  ),
  'group.view' => 
  array (
    0 => 
    array (
      'event.parent' => NULL,
      'shoutbox.display' => NULL,
    ),
    1 => 
    array (
      'forum.parent' => NULL,
    ),
    2 => 
    array (
      'video.parent' => NULL,
      'photo.parent' => NULL,
      'feed.display' => NULL,
    ),
  ),
  'error.display' => 
  array (
    1 => 
    array (
      'pages.photo' => NULL,
    ),
  ),
  'poll.profile' => 
  array (
    1 => 
    array (
      'profile.pic' => NULL,
    ),
  ),
  'marketplace.index' => 
  array (
    3 => 
    array (
      'marketplace.sponsored' => NULL,
      'marketplace.invite' => NULL,
      'marketplace.featured' => NULL,
    ),
    1 => 
    array (
      'marketplace.category' => NULL,
    ),
  ),
  'rss' => 
  array (
    1 => 
    array (
      'rss.info' => NULL,
    ),
  ),
  'video.profile' => 
  array (
    1 => 
    array (
      'profile.pic' => NULL,
    ),
  ),
  'forum' => 
  array (
    4 => 
    array (
      'forum.timezone' => NULL,
    ),
  ),
  'request.index' => 
  array (
    1 => 
    array (
      'request.feed' => NULL,
    ),
  ),
  'blog.profile' => 
  array (
    1 => 
    array (
      'profile.pic' => NULL,
    ),
    3 => 
    array (
      'blog.categories' => NULL,
    ),
  ),
  'admincp.index' => 
  array (
    1 => 
    array (
      'admincp.tips' => NULL,
      'core.note' => NULL,
      'core.site-stat' => NULL,
      'core.active-admin' => NULL,
      'core.latest-admin-login' => NULL,
      'core.news' => NULL,
    ),
  ),
  'quiz.view' => 
  array (
    1 => 
    array (
      'quiz.stat' => NULL,
    ),
  ),
  'profile.info' => 
  array (
    2 => 
    array (
      'profile.info' => NULL,
      'custom.cf_about_me' => NULL,
      'custom.cf_who_i_d_like_to_meet' => NULL,
      'custom.cf_movies' => NULL,
      'custom.cf_interests' => NULL,
      'custom.cf_music' => NULL,
    ),
    3 => 
    array (
      'friend.mutual-friend' => NULL,
    ),
    4 => 
    array (
      'custom.cf_drinker' => NULL,
      'custom.cf_smoker' => NULL,
    ),
  ),
  'mail.compose' => 
  array (
    1 => 
    array (
      'mail.folder' => NULL,
    ),
  ),
  'mail.view' => 
  array (
    1 => 
    array (
      'mail.folder' => NULL,
    ),
  ),
  'mail.sentbox' => 
  array (
    1 => 
    array (
      'mail.folder' => NULL,
    ),
  ),
  'video.index' => 
  array (
    1 => 
    array (
      'video.category' => NULL,
    ),
    3 => 
    array (
      'video.sponsored' => NULL,
      'video.featured' => NULL,
      'tag.cloud' => NULL,
    ),
  ),
  'core.index-member' => 
  array (
    7 => 
    array (
      'announcement.index' => NULL,
      'core.welcome' => NULL,
    ),
    0 => 
    array (
      'forum.timezone' => NULL,
    ),
    2 => 
    array (
      'feed.display' => NULL,
    ),
    3 => 
    array (
      'friend.birthday' => NULL,
      'friend.suggestion' => NULL,
      'poke.display' => 'a:1:{i:0;s:1:"3";}',
      'tag.cloud' => NULL,
    ),
  ),
  'mail.index' => 
  array (
    1 => 
    array (
      'mail.folder' => NULL,
    ),
  ),
  'photo.index' => 
  array (
    3 => 
    array (
      'photo.sponsored' => NULL,
      'photo.featured' => NULL,
      'tag.cloud' => NULL,
    ),
    1 => 
    array (
      'photo.category' => NULL,
    ),
  ),
  '' => 
  array (
    11 => 
    array (
      'user.register-top' => NULL,
    ),
  ),
  'event.index' => 
  array (
    3 => 
    array (
      'friend.birthday' => NULL,
      'event.invite' => NULL,
      'event.sponsored' => NULL,
      'event.featured' => NULL,
    ),
    1 => 
    array (
      'event.category' => NULL,
    ),
  ),
  'music.browse.song' => 
  array (
    1 => 
    array (
      'music.sponsored-song' => NULL,
      'music.list' => NULL,
    ),
  ),
  'photo.battle' => 
  array (
    1 => 
    array (
      'photo.category' => NULL,
    ),
  ),
  'user.browse' => 
  array (
    1 => 
    array (
      'user.filter' => NULL,
      'user.featured' => NULL,
    ),
  ),
  'music.view-album' => 
  array (
    1 => 
    array (
      'music.photo-album' => NULL,
      'music.album-info' => NULL,
    ),
    3 => 
    array (
      'music.track' => NULL,
    ),
  ),
  'blog.view' => 
  array (
    3 => 
    array (
      'track.recent-views' => NULL,
    ),
  ),
  'pages.profile' => 
  array (
    1 => 
    array (
      'profile.pic' => NULL,
    ),
  ),
  'music.index' => 
  array (
    1 => 
    array (
      'music.list' => NULL,
    ),
    3 => 
    array (
      'music.new-album' => NULL,
      'music.featured' => NULL,
    ),
  ),
  'photo.view' => 
  array (
    0 => 
    array (
      'photo.detail' => NULL,
    ),
    3 => 
    array (
      'photo.detail' => NULL,
    ),
  ),
  'profile.index' => 
  array (
    1 => 
    array (
      'friend.profile.small' => NULL,
    ),
    3 => 
    array (
      'feed.time' => NULL,
      'friend.mutual-friend' => NULL,
      'track.recent-views' => NULL,
    ),
    2 => 
    array (
      'feed.display' => NULL,
    ),
  ),
  'event.profile' => 
  array (
    1 => 
    array (
      'profile.pic' => NULL,
    ),
  ),
  'marketplace.view' => 
  array (
    1 => 
    array (
      'marketplace.image' => NULL,
      'marketplace.my' => NULL,
    ),
  ),
  'pages.view' => 
  array (
    1 => 
    array (
      'pages.like' => NULL,
    ),
    3 => 
    array (
      'pages.widget' => NULL,
      'pages.admin' => NULL,
      'shoutbox.display' => NULL,
    ),
    2 => 
    array (
      'feed.display' => NULL,
    ),
  ),
  'photo.album' => 
  array (
    3 => 
    array (
      'photo.album-tag' => NULL,
    ),
  ),
  'quiz.profile' => 
  array (
    1 => 
    array (
      'track.recent-views' => NULL,
      'profile.pic' => NULL,
    ),
  ),
  'friend.profile' => 
  array (
    1 => 
    array (
      'profile.pic' => NULL,
    ),
  ),
  'pages.index' => 
  array (
    1 => 
    array (
      'pages.category' => NULL,
    ),
  ),
  'blog.index' => 
  array (
    1 => 
    array (
      'blog.categories' => NULL,
    ),
    3 => 
    array (
      'tag.cloud' => NULL,
      'blog.top' => NULL,
      'track.recent-views' => NULL,
    ),
  ),
  'event.view' => 
  array (
    3 => 
    array (
      'event.rsvp' => NULL,
    ),
    1 => 
    array (
      'event.image' => NULL,
      'event.map' => NULL,
      'event.attending' => NULL,
    ),
    4 => 
    array (
      'feed.display' => NULL,
    ),
  ),
  'music.browse.album' => 
  array (
    3 => 
    array (
      'music.featured-album' => NULL,
    ),
  ),
  'video.view' => 
  array (
    3 => 
    array (
      'video.related' => NULL,
    ),
  ),
  'forum.index' => 
  array (
    1 => 
    array (
      'log.active-users' => NULL,
      'forum.stat' => NULL,
    ),
  ),
  'music.album' => 
  array (
    3 => 
    array (
      'music.track' => NULL,
    ),
  ),
); ?>