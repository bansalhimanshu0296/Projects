<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '31',
  'type_id' => '0',
  'ordering' => '1',
  'm_connection' => 'core.index-member',
  'component' => 'index',
  'location' => '7',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'announcement',
  'source_parsed' => NULL,
); ?>