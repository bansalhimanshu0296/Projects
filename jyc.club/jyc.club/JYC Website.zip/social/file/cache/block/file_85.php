<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '85',
  'type_id' => '0',
  'ordering' => '5',
  'm_connection' => 'pages.view',
  'component' => 'widget',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'pages',
  'source_parsed' => NULL,
); ?>