<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '107',
  'type_id' => '0',
  'ordering' => '7',
  'm_connection' => 'core.index-member',
  'component' => 'cloud',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'tag',
  'source_parsed' => NULL,
); ?>