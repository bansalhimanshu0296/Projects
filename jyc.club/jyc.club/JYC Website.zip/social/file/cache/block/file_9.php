<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '9',
  'type_id' => '0',
  'ordering' => '3',
  'm_connection' => 'profile.info',
  'component' => 'cf_who_i_d_like_to_meet',
  'location' => '2',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'custom',
  'source_parsed' => NULL,
); ?>