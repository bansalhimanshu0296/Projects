<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '43',
  'type_id' => '0',
  'ordering' => '2',
  'm_connection' => 'event.index',
  'component' => 'invite',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'event',
  'source_parsed' => NULL,
); ?>