<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '15',
  'type_id' => '0',
  'ordering' => '7',
  'm_connection' => 'profile.info',
  'component' => 'cf_music',
  'location' => '2',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'custom',
  'source_parsed' => NULL,
); ?>