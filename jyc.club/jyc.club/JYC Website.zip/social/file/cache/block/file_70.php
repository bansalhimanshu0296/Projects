<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '70',
  'type_id' => '0',
  'ordering' => '2',
  'm_connection' => 'marketplace.view',
  'component' => 'image',
  'location' => '1',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'marketplace',
  'source_parsed' => NULL,
); ?>