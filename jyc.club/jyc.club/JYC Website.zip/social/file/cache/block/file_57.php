<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '57',
  'type_id' => '0',
  'ordering' => '2',
  'm_connection' => 'profile.index',
  'component' => 'profile.small',
  'location' => '1',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'friend',
  'source_parsed' => NULL,
); ?>