<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '77',
  'type_id' => '0',
  'ordering' => '1',
  'm_connection' => 'music.browse.song',
  'component' => 'sponsored-song',
  'location' => '1',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'music',
  'source_parsed' => NULL,
); ?>