<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '62',
  'type_id' => '0',
  'ordering' => '1',
  'm_connection' => 'event.index',
  'component' => 'birthday',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'friend',
  'source_parsed' => NULL,
); ?>