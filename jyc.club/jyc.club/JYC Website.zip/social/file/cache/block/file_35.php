<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '35',
  'type_id' => '0',
  'ordering' => '2',
  'm_connection' => 'blog.profile',
  'component' => 'categories',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'blog',
  'source_parsed' => NULL,
); ?>