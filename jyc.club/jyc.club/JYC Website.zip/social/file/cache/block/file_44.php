<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '44',
  'type_id' => '0',
  'ordering' => '5',
  'm_connection' => 'event.index',
  'component' => 'featured',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'event',
  'source_parsed' => NULL,
); ?>