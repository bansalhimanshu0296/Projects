<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '34',
  'type_id' => '0',
  'ordering' => '5',
  'm_connection' => 'blog.index',
  'component' => 'top',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'blog',
  'source_parsed' => NULL,
); ?>