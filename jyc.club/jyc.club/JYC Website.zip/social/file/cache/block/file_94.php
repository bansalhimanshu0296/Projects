<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '94',
  'type_id' => '0',
  'ordering' => '5',
  'm_connection' => 'group.view',
  'component' => 'parent',
  'location' => '2',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'photo',
  'source_parsed' => NULL,
); ?>