<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '38',
  'type_id' => '0',
  'ordering' => '1',
  'm_connection' => 'group.view',
  'component' => 'parent',
  'location' => '0',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'event',
  'source_parsed' => NULL,
); ?>