<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '87',
  'type_id' => '0',
  'ordering' => '6',
  'm_connection' => 'pages.view',
  'component' => 'admin',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'pages',
  'source_parsed' => NULL,
); ?>