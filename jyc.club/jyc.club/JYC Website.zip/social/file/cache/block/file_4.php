<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '4',
  'type_id' => '0',
  'ordering' => '4',
  'm_connection' => 'admincp.index',
  'component' => 'active-admin',
  'location' => '1',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'core',
  'source_parsed' => NULL,
); ?>