<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '81',
  'type_id' => '0',
  'ordering' => '5',
  'm_connection' => 'music.index',
  'component' => 'featured',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'music',
  'source_parsed' => NULL,
); ?>