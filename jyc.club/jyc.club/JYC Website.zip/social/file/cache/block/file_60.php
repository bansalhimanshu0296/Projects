<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '60',
  'type_id' => '0',
  'ordering' => '5',
  'm_connection' => 'core.index-member',
  'component' => 'suggestion',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'friend',
  'source_parsed' => NULL,
); ?>