<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '28',
  'type_id' => '0',
  'ordering' => '1',
  'm_connection' => 'user.browse',
  'component' => 'filter',
  'location' => '1',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'user',
  'source_parsed' => NULL,
); ?>