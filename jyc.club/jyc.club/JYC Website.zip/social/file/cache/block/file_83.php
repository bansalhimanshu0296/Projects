<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '83',
  'type_id' => '0',
  'ordering' => '2',
  'm_connection' => 'pages.view',
  'component' => 'like',
  'location' => '1',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'pages',
  'source_parsed' => NULL,
); ?>