<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '47',
  'type_id' => '0',
  'ordering' => '9',
  'm_connection' => 'profile.index',
  'component' => 'display',
  'location' => '2',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'feed',
  'source_parsed' => NULL,
); ?>