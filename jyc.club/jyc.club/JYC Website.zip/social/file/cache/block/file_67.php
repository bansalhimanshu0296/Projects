<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '67',
  'type_id' => '0',
  'ordering' => '3',
  'm_connection' => 'marketplace.view',
  'component' => 'my',
  'location' => '1',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'marketplace',
  'source_parsed' => NULL,
); ?>