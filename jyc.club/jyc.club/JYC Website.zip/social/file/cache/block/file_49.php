<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '49',
  'type_id' => '0',
  'ordering' => '5',
  'm_connection' => 'profile.index',
  'component' => 'time',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'feed',
  'source_parsed' => NULL,
); ?>