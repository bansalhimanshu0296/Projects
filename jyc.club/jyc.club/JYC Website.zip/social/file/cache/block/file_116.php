<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '116',
  'type_id' => '0',
  'ordering' => '4',
  'm_connection' => 'video.index',
  'component' => 'featured',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'video',
  'source_parsed' => NULL,
); ?>