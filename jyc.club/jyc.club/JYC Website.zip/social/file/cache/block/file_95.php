<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '95',
  'type_id' => '0',
  'ordering' => '1',
  'm_connection' => 'photo.index',
  'component' => 'sponsored',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'photo',
  'source_parsed' => NULL,
); ?>