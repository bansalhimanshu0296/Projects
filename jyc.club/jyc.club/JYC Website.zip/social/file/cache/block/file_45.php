<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '45',
  'type_id' => '0',
  'ordering' => '12',
  'm_connection' => 'group.view',
  'component' => 'display',
  'location' => '2',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'feed',
  'source_parsed' => NULL,
); ?>