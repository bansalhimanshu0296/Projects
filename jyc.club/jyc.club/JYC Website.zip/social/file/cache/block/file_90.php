<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '90',
  'type_id' => '0',
  'ordering' => '2',
  'm_connection' => 'photo.view',
  'component' => 'detail',
  'location' => '0',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'photo',
  'source_parsed' => NULL,
); ?>