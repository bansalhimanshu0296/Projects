<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'photo.rate' => 
  array (
    'photo.stat' => false,
    'photo.category' => false,
  ),
  'photo.profile' => 
  array (
    'profile.pic' => false,
  ),
  'core.index' => 
  array (
    'forum.timezone' => false,
    'blog.new-blogs' => false,
  ),
  'marketplace.profile' => 
  array (
    'profile.pic' => false,
  ),
  'music.profile' => 
  array (
    'profile.pic' => false,
  ),
  'group.view' => 
  array (
    'event.parent' => true,
    'forum.parent' => true,
    'video.parent' => true,
    'photo.parent' => true,
    'shoutbox.display' => true,
    'feed.display' => false,
  ),
  'error.display' => 
  array (
    'pages.photo' => false,
  ),
  'poll.profile' => 
  array (
    'profile.pic' => false,
  ),
  'marketplace.index' => 
  array (
    'marketplace.sponsored' => false,
    'marketplace.category' => false,
    'marketplace.invite' => false,
    'marketplace.featured' => false,
  ),
  'rss' => 
  array (
    'rss.info' => false,
  ),
  'video.profile' => 
  array (
    'profile.pic' => false,
  ),
  'forum' => 
  array (
    'forum.timezone' => false,
  ),
  'request.index' => 
  array (
    'request.feed' => false,
  ),
  'blog.profile' => 
  array (
    'profile.pic' => false,
    'blog.categories' => false,
  ),
  'admincp.index' => 
  array (
    'admincp.tips' => false,
    'core.note' => true,
    'core.site-stat' => true,
    'core.active-admin' => true,
    'core.latest-admin-login' => true,
    'core.news' => true,
  ),
  'quiz.view' => 
  array (
    'quiz.stat' => false,
  ),
  'profile.info' => 
  array (
    'profile.info' => true,
    'custom.cf_about_me' => true,
    'custom.cf_who_i_d_like_to_meet' => true,
    'custom.cf_movies' => true,
    'custom.cf_interests' => true,
    'custom.cf_music' => true,
    'friend.mutual-friend' => true,
    'custom.cf_drinker' => true,
    'custom.cf_smoker' => true,
  ),
  'mail.compose' => 
  array (
    'mail.folder' => false,
  ),
  'mail.view' => 
  array (
    'mail.folder' => false,
  ),
  'mail.sentbox' => 
  array (
    'mail.folder' => false,
  ),
  'video.index' => 
  array (
    'video.category' => false,
    'video.sponsored' => false,
    'video.featured' => false,
    'tag.cloud' => false,
  ),
  'core.index-member' => 
  array (
    'announcement.index' => false,
    'core.welcome' => false,
    'forum.timezone' => false,
    'feed.display' => false,
    'friend.birthday' => true,
    'friend.suggestion' => true,
    'poke.display' => true,
    'tag.cloud' => false,
  ),
  'mail.index' => 
  array (
    'mail.folder' => false,
  ),
  'photo.index' => 
  array (
    'photo.sponsored' => false,
    'photo.category' => false,
    'photo.featured' => false,
    'tag.cloud' => false,
  ),
  '' => 
  array (
    'user.register-top' => false,
  ),
  'event.index' => 
  array (
    'friend.birthday' => false,
    'event.invite' => false,
    'event.sponsored' => false,
    'event.category' => false,
    'event.featured' => false,
  ),
  'music.browse.song' => 
  array (
    'music.sponsored-song' => false,
    'music.list' => false,
  ),
  'photo.battle' => 
  array (
    'photo.category' => false,
  ),
  'user.browse' => 
  array (
    'user.filter' => false,
    'user.featured' => false,
  ),
  'music.view-album' => 
  array (
    'music.photo-album' => false,
    'music.album-info' => false,
    'music.track' => false,
  ),
  'blog.view' => 
  array (
    'track.recent-views' => false,
  ),
  'pages.profile' => 
  array (
    'profile.pic' => false,
  ),
  'music.index' => 
  array (
    'music.list' => false,
    'music.new-album' => false,
    'music.featured' => false,
  ),
  'photo.view' => 
  array (
    'photo.detail' => false,
  ),
  'profile.index' => 
  array (
    'friend.profile.small' => true,
    'feed.time' => false,
    'friend.mutual-friend' => true,
    'track.recent-views' => true,
    'feed.display' => false,
  ),
  'event.profile' => 
  array (
    'profile.pic' => false,
  ),
  'marketplace.view' => 
  array (
    'marketplace.image' => false,
    'marketplace.my' => false,
  ),
  'pages.view' => 
  array (
    'pages.like' => true,
    'pages.widget' => true,
    'pages.admin' => true,
    'shoutbox.display' => true,
    'feed.display' => false,
  ),
  'photo.album' => 
  array (
    'photo.album-tag' => false,
  ),
  'quiz.profile' => 
  array (
    'track.recent-views' => false,
    'profile.pic' => false,
  ),
  'friend.profile' => 
  array (
    'profile.pic' => false,
  ),
  'pages.index' => 
  array (
    'pages.category' => true,
  ),
  'blog.index' => 
  array (
    'blog.categories' => false,
    'tag.cloud' => false,
    'blog.top' => false,
    'track.recent-views' => false,
  ),
  'event.view' => 
  array (
    'event.rsvp' => false,
    'event.image' => false,
    'event.map' => false,
    'event.attending' => false,
    'feed.display' => false,
  ),
  'music.browse.album' => 
  array (
    'music.featured-album' => false,
  ),
  'video.view' => 
  array (
    'video.related' => false,
  ),
  'forum.index' => 
  array (
    'log.active-users' => false,
    'forum.stat' => false,
  ),
  'music.album' => 
  array (
    'music.track' => false,
  ),
); ?>