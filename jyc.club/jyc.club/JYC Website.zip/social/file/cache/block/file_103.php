<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '103',
  'type_id' => '0',
  'ordering' => '7',
  'm_connection' => 'pages.view',
  'component' => 'display',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'shoutbox',
  'source_parsed' => NULL,
); ?>