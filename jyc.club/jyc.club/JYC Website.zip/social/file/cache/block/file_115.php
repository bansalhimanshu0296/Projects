<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '115',
  'type_id' => '0',
  'ordering' => '2',
  'm_connection' => 'video.index',
  'component' => 'sponsored',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'video',
  'source_parsed' => NULL,
); ?>