<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '14',
  'type_id' => '0',
  'ordering' => '6',
  'm_connection' => 'profile.info',
  'component' => 'cf_interests',
  'location' => '2',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'custom',
  'source_parsed' => NULL,
); ?>