<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '51',
  'type_id' => '0',
  'ordering' => '10',
  'm_connection' => 'pages.view',
  'component' => 'display',
  'location' => '2',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'feed',
  'source_parsed' => NULL,
); ?>