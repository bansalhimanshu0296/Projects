<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '98',
  'type_id' => '0',
  'ordering' => '6',
  'm_connection' => 'core.index-member',
  'component' => 'display',
  'location' => '3',
  'disallow_access' => 'a:1:{i:0;s:1:"3";}',
  'can_move' => '1',
  'module_id' => 'poke',
  'source_parsed' => NULL,
); ?>