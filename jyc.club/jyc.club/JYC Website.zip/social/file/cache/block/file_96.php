<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '96',
  'type_id' => '0',
  'ordering' => '2',
  'm_connection' => 'photo.album',
  'component' => 'album-tag',
  'location' => '3',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'photo',
  'source_parsed' => NULL,
); ?>