<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '18',
  'type_id' => '0',
  'ordering' => '1',
  'm_connection' => 'profile.info',
  'component' => 'info',
  'location' => '2',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'profile',
  'source_parsed' => NULL,
); ?>