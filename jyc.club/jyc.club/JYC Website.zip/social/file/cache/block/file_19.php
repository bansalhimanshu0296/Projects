<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '19',
  'type_id' => '0',
  'ordering' => '1',
  'm_connection' => 'blog.profile',
  'component' => 'pic',
  'location' => '1',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'profile',
  'source_parsed' => NULL,
); ?>