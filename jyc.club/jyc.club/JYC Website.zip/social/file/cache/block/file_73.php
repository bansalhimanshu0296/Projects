<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '73',
  'type_id' => '0',
  'ordering' => '3',
  'm_connection' => 'music.view-album',
  'component' => 'album-info',
  'location' => '1',
  'disallow_access' => NULL,
  'can_move' => '0',
  'module_id' => 'music',
  'source_parsed' => NULL,
); ?>