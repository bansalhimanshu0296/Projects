<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '12',
  'type_id' => '0',
  'ordering' => '11',
  'm_connection' => 'profile.info',
  'component' => 'cf_drinker',
  'location' => '4',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'custom',
  'source_parsed' => NULL,
); ?>