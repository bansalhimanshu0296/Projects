<?php defined('PHPFOX') or exit('NO DICE!'); ?>
<?php $aContent = array (
  'block_id' => '3',
  'type_id' => '0',
  'ordering' => '2',
  'm_connection' => 'admincp.index',
  'component' => 'note',
  'location' => '1',
  'disallow_access' => NULL,
  'can_move' => '1',
  'module_id' => 'core',
  'source_parsed' => NULL,
); ?>